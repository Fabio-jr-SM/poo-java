package br.com.localiza.estacionamento;

public class Main {

    static Veiculo[] listaVeiculo = new Veiculo[10];

    public static void main(String[] args) {
        menu();
    }

    //Alterar
    public static void alterar() {
        String placa = Teclado.lerString("Placa");
        for (int i = 0; i < listaVeiculo.length; i++) {
            if (listaVeiculo[i] != null && listaVeiculo[i].getPlaca().equalsIgnoreCase(placa)) {
                System.out.println("Alterando veículo: " + listaVeiculo[i]);

                if (listaVeiculo[i] instanceof Carro) {
                    Carro carro = (Carro) listaVeiculo[i];
                    carro.setMarca(Teclado.lerString("Marca"));
                    carro.setModelo(Teclado.lerString("Modelo"));
                    carro.setAnoFabricacao(Teclado.lerInteiro("Ano"));
                    carro.setQuantidadePortas(Teclado.lerInteiro("Portas"));
                } else if (listaVeiculo[i] instanceof Moto) {
                    Moto moto = (Moto) listaVeiculo[i];
                    moto.setMarca(Teclado.lerString("Marca"));
                    moto.setModelo(Teclado.lerString("Modelo"));
                    moto.setAnoFabricacao(Teclado.lerInteiro("Ano"));
                    moto.setCilindradas(Teclado.lerInteiro("Cilindradas"));
                }
                System.out.println("Veículo atualizado com sucesso!");
                menu();
                return;
            }
        }
        System.out.println("Placa não encontrada!");
        menu();
    }

    //Menu
    public static void menu() {
        System.out.println("\n=========== MENU ============\n" +
                           "[1] Cadastrar\n" +
                           "[2] Alterar\n" +
                           "[3] Excluir\n" +
                           "[4] Consultar\n" +
                           "[5] Sair");

        int opcao = Teclado.lerInteiro("Opção: ");

        switch (opcao) {
            case 1: cadastrar(); break;
            case 2: alterar(); break;
            case 3: excluir(); break;
            case 4: consultar(); break;
            case 5: System.exit(0);
            default:
                System.out.println("Opção inválida! Tente novamente.");
                menu();
        }
    }
    
    public static void excluir() {
    	
    	String placaExluir = Teclado.lerString("Digite a placa: ");
    	
    	for (int i = 0; i < listaVeiculo.length; i++) {
            if (listaVeiculo[i].placa == placaExluir) {
                listaVeiculo[i] = null;
                System.out.println("Excluido com sucesso!");
                break;
            }
        }
        System.out.println("Placa não encontrada!\n");
    }

    
    //Cadastrar
    public static void cadastrar() {
        int tipoVeiculo = Teclado.lerInteiro("Tipo de veículo (1-Moto | 2-Carro): ");
        String placa = Teclado.lerString("Placa");
        String marca = Teclado.lerString("Marca");
        String modelo = Teclado.lerString("Modelo");
        int anoFabricacao = Teclado.lerInteiro("Ano");

        Veiculo veiculo = null;

        if (tipoVeiculo == 1) {
            int cilindradas = Teclado.lerInteiro("Cilindradas");
            veiculo = new Moto(placa, marca, modelo, anoFabricacao, cilindradas);
        } else if (tipoVeiculo == 2) {
            int quantidadePortas = Teclado.lerInteiro("Portas");
            veiculo = new Carro(placa, marca, modelo, anoFabricacao, quantidadePortas);
        } else {
            System.out.println("Opção inválida! Retornando ao menu.");
            menu();
            return;
        }

        if (adicionarVeiculo(veiculo)) {
            System.out.println("Veículo cadastrado com sucesso!");
        } else {
            System.out.println("Não há espaço para mais veículos!");
        }
        menu();
    }

    public static boolean adicionarVeiculo(Veiculo v) {
        for (int i = 0; i < listaVeiculo.length; i++) {
            if (listaVeiculo[i] == null) {
                listaVeiculo[i] = v;
                return true;
            }
        }
        return false;
    }

    public static void consultar() {
        boolean encontrou = false;
        for (Veiculo veiculo : listaVeiculo) {
            if (veiculo != null) {
                System.out.println(veiculo);
                encontrou = true;
            }
        }
        if (!encontrou) {
            System.out.println("Nenhum veículo cadastrado!");
        }
        menu();
    }
}
